# Research Telemetry Data Dictionary (v2.0.0)

## Core Files in Package
- `events.csv`: Append-only interaction and system events across 25 schema event types.
- `sessions.csv`: Unique participant sessions, condition assignment, duration, and event counts.
- `tasks.csv`: Sanitized task specifications, course learning objectives (CLOs), domains, and difficulty.
- `test_cases.csv`: Standardized evaluation test cases across the 10 scenario types.
- `expert_reviews.csv`: 10-dimension faculty evaluations, overall pass/fail, and critical failure indicators.
- `cew_submissions.csv`: Learner Claim-Evidence-Warrant text, confidence ratings, and solve timings.
- `cew_scores.csv`: Automated and human expert CEW ratings (1-3) with component rationales.
- `guardrail_events.csv`: Detected disclosure, injection, or solution bypass events.
- `telemetry_validation.csv`: Expected vs. observed telemetry completeness reports.
- `export_manifest.json`: SHA-256 cryptographic hashes and record counts for all packaged files.
